from Crypto.Util.number import getPrime
from gmpy import invert
def generate_key():
    p = getPrime(2048)
    q = getPrime(2048)
    n = p*q
    phi = (p-1) * (q-1)
    e = 65537
    d = invert(e,phi)
    return [n,e,d]

m = "ASCWG{y0u_N33d_t0_Brut3_F0rce_th3_???}"
m = int(m.encode("hex"),16)
n,e,d = generate_key()
c = pow(m,e,n)
print "n = " , n
print "e = " ,e
print "c =",c
